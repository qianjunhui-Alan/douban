const login = document.querySelector(".login");
login.addEventListener("click" , ()=>{
    window.location = "/login";
})

const register = document.querySelector(".register");
register.addEventListener("click" , ()=>{
    window.location = "/sign";
})